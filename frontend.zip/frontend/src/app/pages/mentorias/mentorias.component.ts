import { HttpErrorResponse } from '@angular/common/http';
import { NgTemplateOutlet } from '@angular/common';
import { Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AgendaService } from '../../agenda/agenda.service';
import { SessaoService } from '../../auth/sessao.service';
import { mensagemDeErro } from '../../auth/mensagem-erro';
import { ConviteService } from '../../convites/convite.service';
import { Agendamento, ConviteDetalhe, StatusAgendamento } from '../../models';
import { AbasListaComponent } from '../../shared/abas-lista/abas-lista.component';
import { AbaLista, escolherAba } from '../../shared/abas-lista/abas-lista.utils';
import { dataHoraCompleta, hora, jaPassou } from '../../shared/data.utils';
import { descreverMaturidade } from '../../shared/maturidade.utils';
import { formatarDuracao, formatarValorSessao, linkSeguro } from '../../shared/mentoria.utils';
import { formatarWhatsapp, linkWhatsapp } from '../../shared/whatsapp.utils';
import { EstrelasComponent } from '../../shared/estrelas/estrelas.component';
import { iniciais } from '../../shared/texto.utils';

type Situacao = 'AGUARDANDO' | 'CONFIRMADA' | 'REALIZADA' | 'RECUSADA' | 'CANCELADA';
type AbaMentoria = 'pendentes' | 'ativos' | 'encerrados';

const ROTULOS_ABAS: Record<AbaMentoria, string> = {
  ativos: 'Ativos',
  pendentes: 'Propostas pendentes',
  encerrados: 'Encerrados',
};

// "Mentorias": as sessões agendadas dos dois lados (fluxo estilo Preply) e as sugestões de mentoria, em três abas.
//  - Propostas pendentes
//      Startup: sugestões recebidas dos mentores e pedidos que ainda esperam o mentor (ou o pagamento do Pix).
//      Mentor: pedidos para confirmar (com o link do Meet) e sugestões enviadas que a startup ainda não respondeu.
//  - Ativos: próximas sessões confirmadas (com o link do Meet).
//  - Encerrados: histórico (realizadas, recusadas, canceladas, expiradas) e, para o mentor, sugestões já respondidas.
// A aba aberta fica na URL (?aba=ativos); a bolinha de aviso marca a aba com algo esperando a pessoa.
@Component({
  selector: 'app-mentorias',
  standalone: true,
  imports: [FormsModule, RouterLink, EstrelasComponent, NgTemplateOutlet, AbasListaComponent],
  templateUrl: './mentorias.component.html',
})
export class MentoriasComponent implements OnInit {
  private agendaService = inject(AgendaService);
  private conviteService = inject(ConviteService);
  private sessao = inject(SessaoService);

  // Vem da URL (?aba=...) por withComponentInputBinding
  aba = input<string>();

  ehMentor = computed(() => this.sessao.tipo() === 'MENTOR');
  agendamentos = signal<Agendamento[]>([]);
  sugestoes = signal<ConviteDetalhe[]>([]);
  carregando = signal(true);
  erro = signal('');
  agindoId = signal<number | null>(null);
  // Link do Meet digitado em cada pedido, antes de confirmar
  links: Record<number, string> = {};

  pedidos = computed(() =>
    this.agendamentos().filter((a) => a.status === 'PENDENTE' && !jaPassou(a.inicio)),
  );
  // Só as confirmadas e que ainda não aconteceram. Os pedidos que esperam o mentor ficam em "Propostas pendentes".
  proximas = computed(() => this.agendamentos().filter((a) => a.status === 'CONFIRMADO' && !jaPassou(a.fim)));
  historico = computed(() => {
    const ativos = new Set([...this.pedidos(), ...this.proximas()].map((a) => a.id));
    return this.agendamentos().filter((a) => !ativos.has(a.id)).reverse();
  });
  sugestoesPendentes = computed(() => this.sugestoes().filter((c) => c.status === 'PENDENTE'));
  // Sugestões que o mentor enviou e a startup já respondeu (agendou ou dispensou)
  sugestoesRespondidas = computed(() => this.sugestoes().filter((c) => c.status !== 'PENDENTE'));

  // ---------- Abas ----------
  abaAtual = computed(() =>
    this.aba() === 'pendentes' || this.aba() === 'encerrados' ? escolherAba<AbaMentoria>(this.aba(), [
      { chave: 'ativos', quantidade: this.proximas().length },
      { chave: 'pendentes', quantidade: this.pedidos().length + this.sugestoesPendentes().length },
      { chave: 'encerrados', quantidade: this.historico().length + this.sugestoesRespondidas().length },
    ]) : 'ativos',
  );
  // Bolinha de aviso só onde a pessoa precisa agir:
  //   pendentes:  mentor, com pedidos para confirmar; startup, com sugestões para responder ou Pix para pagar
  //   encerrados: startup, com mentoria realizada ainda sem avaliação
  abas = computed<AbaLista[]>(() => {
    const avisos: Record<AbaMentoria, boolean> = {
      pendentes: this.ehMentor()
        ? this.pedidos().length > 0
        : this.sugestoesPendentes().length > 0 || this.pedidos().some((a) => a.statusPagamento === 'AGUARDANDO'),
      ativos: false,
      encerrados: this.historico().some((a) => this.podeAvaliar(a)),
    };
    return (Object.keys(ROTULOS_ABAS) as AbaMentoria[]).map((chave) => ({
      chave,
      rotulo: ROTULOS_ABAS[chave],
      notificacao: avisos[chave],
    }));
  });

  // Números do topo da página
  realizadas = computed(() => this.agendamentos().filter((a) => a.realizada));
  notaMedia = computed(() => {
    const notas = this.realizadas().map((a) => a.avaliacao?.nota).filter((n): n is number => !!n);
    return notas.length ? notas.reduce((t, n) => t + n, 0) / notas.length : null;
  });
  totalPago = computed(() =>
    this.agendamentos()
      .filter((a) => a.statusPagamento === 'PAGO')
      .reduce((t, a) => t + Number(a.valor), 0),
  );
  totalPagoTexto = computed(() => formatarValorSessao(this.totalPago()).replace('Gratuita', 'R$ 0,00'));
  notaMediaTexto = computed(() => this.notaMedia()?.toLocaleString('pt-BR', { maximumFractionDigits: 1, minimumFractionDigits: 1 }) ?? '–');

  // Avaliação sendo escrita (startup), por mentoria
  notas: Record<number, number> = {};
  comentarios: Record<number, string> = {};
  notaHover = signal<{ id: number; nota: number } | null>(null);

  ngOnInit() {
    this.carregar();
  }

  carregar() {
    this.carregando.set(true);
    this.erro.set('');
    const mentorId = this.sessao.mentorId();
    const startupId = this.sessao.startupId();

    const agendamentos = mentorId !== null ? this.agendaService.doMentor(mentorId) : startupId !== null ? this.agendaService.daStartup(startupId) : null;
    const sugestoes =
      mentorId !== null
        ? this.conviteService.detalhadosDoMentor(mentorId)
        : startupId !== null
          ? this.conviteService.detalhadosDaStartup(startupId)
          : null;
    if (!agendamentos || !sugestoes) {
      this.carregando.set(false);
      return;
    }

    agendamentos.subscribe({
      next: (lista) => {
        this.agendamentos.set(lista);
        this.carregando.set(false);
      },
      error: (e: HttpErrorResponse) => {
        this.erro.set(mensagemDeErro(e, 'Não foi possível carregar as mentorias.'));
        this.carregando.set(false);
      },
    });
    // Sugestões são os convites que partiram do mentor
    sugestoes.subscribe({
      next: (lista) => this.sugestoes.set(lista.filter((c) => c.enviadoPor === 'MENTOR')),
      error: () => {},
    });
  }

  confirmar(a: Agendamento) {
    const link = (this.links[a.id] ?? '').trim();
    if (!/^https:\/\/\S+$/.test(link)) {
      this.erro.set('Cole o link da reunião do Google Meet (começa com https://) para confirmar.');
      return;
    }
    this.agir(a.id, this.agendaService.confirmar(a.id, link));
  }

  recusar(a: Agendamento) {
    this.agir(a.id, this.agendaService.recusar(a.id));
  }

  cancelar(a: Agendamento) {
    if (!confirm('Cancelar esta mentoria?')) return;
    this.agir(a.id, this.agendaService.cancelar(a.id));
  }

  dispensarSugestao(c: ConviteDetalhe) {
    this.agindoId.set(c.id);
    this.conviteService.recusar(c.id).subscribe({
      next: () => {
        this.agindoId.set(null);
        this.carregar();
      },
      error: (e: HttpErrorResponse) => {
        this.agindoId.set(null);
        this.erro.set(mensagemDeErro(e, 'Não foi possível dispensar a sugestão.'));
      },
    });
  }

  avaliar(a: Agendamento) {
    const nota = this.notas[a.id];
    if (!nota) {
      this.erro.set('Escolha de 1 a 5 estrelas para avaliar.');
      return;
    }
    this.agir(a.id, this.agendaService.avaliar(a.id, nota, (this.comentarios[a.id] ?? '').trim()));
  }

  notaExibida(a: Agendamento): number {
    const h = this.notaHover();
    return h && h.id === a.id ? h.nota : (this.notas[a.id] ?? 0);
  }

  podeAvaliar(a: Agendamento): boolean {
    return !this.ehMentor() && !!a.realizada && !a.avaliacao;
  }

  iniciaisDe(nome?: string | null): string {
    return iniciais(nome ?? '');
  }

  private agir(id: number, requisicao: ReturnType<AgendaService['recusar']>) {
    if (this.agindoId() !== null) return;
    this.agindoId.set(id);
    this.erro.set('');
    requisicao.subscribe({
      next: () => {
        this.agindoId.set(null);
        this.carregar();
      },
      error: (e: HttpErrorResponse) => {
        this.agindoId.set(null);
        this.erro.set(mensagemDeErro(e, 'Não foi possível concluir a ação. Tente novamente.'));
        this.carregar();
      },
    });
  }

  // ---------- textos do template ----------

  quando(a: Agendamento): string {
    return `${dataHoraCompleta(a.inicio)} até ${hora(a.fim)}`;
  }

  outraParte(a: Agendamento) {
    return this.ehMentor() ? a.startup : a.mentor;
  }

  situacao(a: Agendamento): Situacao {
    const mapa: Record<StatusAgendamento, Situacao> = {
      PENDENTE: 'AGUARDANDO',
      CONFIRMADO: jaPassou(a.fim) ? 'REALIZADA' : 'CONFIRMADA',
      RECUSADO: 'RECUSADA',
      CANCELADO: 'CANCELADA',
    };
    return a.status === 'PENDENTE' && jaPassou(a.inicio) ? 'RECUSADA' : mapa[a.status];
  }

  rotulo(a: Agendamento): string {
    const textos: Record<Situacao, string> = {
      AGUARDANDO: a.statusPagamento === 'AGUARDANDO' ? 'Aguardando pagamento' : 'Aguardando confirmação',
      CONFIRMADA: 'Confirmada',
      REALIZADA: 'Realizada',
      RECUSADA: a.status === 'PENDENTE' ? 'Expirada' : 'Recusada',
      CANCELADA: a.statusPagamento === 'EXPIRADO' ? 'Pix expirado' : 'Cancelada',
    };
    return textos[this.situacao(a)];
  }

  classe(a: Agendamento): string {
    const classes: Record<Situacao, string> = {
      AGUARDANDO: 'bg-ponti-amarelo/30 text-ponti-marinho',
      CONFIRMADA: 'bg-green-100 text-green-800',
      REALIZADA: 'bg-ponti-lilas/40 text-ponti-marinho',
      RECUSADA: 'bg-red-100 text-red-700',
      CANCELADA: 'bg-gray-200 text-gray-700',
    };
    return classes[this.situacao(a)];
  }

  pagamento(a: Agendamento): string {
    const valor = formatarValorSessao(a.valor);
    const metodo =
      a.metodoPagamento === 'CARTAO'
        ? `${a.pagamento?.cartaoBandeira ?? 'cartão'}${a.pagamento?.cartaoFinal ? ' •••• ' + a.pagamento.cartaoFinal : ''}`
        : 'Pix';
    switch (a.statusPagamento) {
      case 'GRATUITA':
        return 'Mentoria gratuita';
      case 'AGUARDANDO':
        return `${valor} · aguardando pagamento do Pix`;
      case 'PAGO':
        return this.ehMentor() ? `${valor} · pago via ${metodo}` : `${valor} pago via ${metodo}`;
      case 'REEMBOLSADO':
        return `${valor} reembolsado`;
      case 'EXPIRADO':
        return 'Pix não pago no prazo';
      default:
        return valor;
    }
  }

  link(a: Agendamento): string | null {
    return linkSeguro(a.linkReuniao);
  }

  // WhatsApp da outra parte: o backend só manda com a mentoria confirmada e se ela autorizou
  whatsapp(a: Agendamento): { link: string; texto: string } | null {
    const numero = this.outraParte(a)?.whatsapp;
    const link = linkWhatsapp(numero);
    return link ? { link, texto: formatarWhatsapp(numero) } : null;
  }

  podeCancelar(a: Agendamento): boolean {
    return (a.status === 'PENDENTE' || a.status === 'CONFIRMADO') && !jaPassou(a.inicio);
  }

  valorDoMentor(c: ConviteDetalhe): string {
    return `${formatarValorSessao(c.mentor?.valorSessao)} por sessão de ${formatarDuracao(c.mentor?.duracaoSessaoMinutos ?? 60)}`;
  }

  maturidade(c: ConviteDetalhe): string {
    return descreverMaturidade(c.startup?.estagioMaturidade);
  }

  rotuloSugestao(c: ConviteDetalhe): string {
    return { PENDENTE: 'Aguardando a startup', ACEITO: 'A startup agendou', RECUSADO: 'Dispensada' }[c.status];
  }
}
